var count = 15;
var checkFire = false;
var counter = setInterval(timer, 1000);

function timer() {
    count = count - 1;
    if (count <= 0) {
        clearInterval(counter);
        return
    }
    document.getElementById("timer").innerHTML = count
}
if (top.frames.length != 0) {
    top.location = window.location
}

function clickEnd() {
    document.getElementById("doSubmitTop").disabled = true;
    document.getElementById("doSubmit").disabled = true;
    document.getElementById("counterMsg").style.visibility = "hidden";
    checkFire = true;
    $.ajax({
        type: "POST",
        url: "clearSession.mellat",
        success: function () {
            document.forms.returnForm.submit()
        }
    })
};


